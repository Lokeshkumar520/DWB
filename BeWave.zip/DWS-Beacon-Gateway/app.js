var mqtt = require('mqtt')
var mqttProfile = require('./config.js')
var registeredBeacons=["AC233F260D98","AC233F260D83"];/*,"AC233F26098","AC233F260DAE","AC233F260D3A"*/ 

//var client  = mqtt.connect('tcp://169.56.102.163',1883)
var options={port: 1883, host: '169.56.102.163', keepalive: 60, clean: true,reconnectPeriod: 1000};
var client = mqtt.connect(mqttProfile.mqttProfile.url,mqttProfile.mqttProfile.options)
var tempData
var Counter=-1;
var timeInterval=2000;
var topicName= '/DWS/RNdata';
var x=true;
var objectarray=[];

const noble = require('noble'); 	
const BeaconScanner = require('node-beacon-scanner');
const scanner = new BeaconScanner({'noble': noble});

// MQTT Connection( which is protocol to send and recieve data )...

client.on('connect', function(){
	console.log('connected');

// Start scanning of Bluetooth Beacons when MQTT Broker is Connected
scanner.startScan().then(() => {
	console.log('Started to scan.');
}).catch((error) => {  //if errors in scanning it will show the errors.
  console.error(error);
});
});

 
// Set an Event handler for becons(on start of scanning several events occurances. for those events it handles 

scanner.onadvertisement = (ad) => { 
tempData=JSON.stringify(ad, null, ' ');
let objtemp=JSON.parse(tempData);

if(objtemp.beaconType=="eddystoneTlm"){	
	//Counter=Counter+1;
	//if(registeredBeacons.includes(objtemp.mac)){
	client.publish(objtemp.mac,JSON.stringify(objtemp));
	//console.log(registeredBeacons.includes(objtemp.mac));
	//console.log(objtemp);		
	//objectarray[Counter]=objtemp;
	//};
			
   };

}



//setInterval(function(){
//client.publish(topicName,JSON.stringify(objectarray));
//console.log(objectarray);
//Counter=-1;
//},timeInterval);
	

